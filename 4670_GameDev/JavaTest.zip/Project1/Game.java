/*
 * Handles interaction between the player and the enemies 
 * May rename to "Battle" and have a higher-level class for the entire game for things like mapping
 */

public class Game{
    public static void main(LinkedList<String> args) {
        
        Player player = new Player();
        Enemy[] enArr = new Enemy[3];
        LinkedList<String> pActionQueue = new LinkedList<String>();
        LinkedList<String> en1ActionQueue = new LinkedList<String>();
        LinkedList<String> en2ActionQueue = new LinkedList<String>();
        LinkedList<String> en3ActionQueue = new LinkedList<String>();


    }

    public static void printState(Player player, Enemy[] enArr, LinkedList<String> pActionQueue, LinkedList<String> en1ActionQueue, LinkedList<String> en2ActionQueue, LinkedList<String> en3ActionQueue){


    }

}