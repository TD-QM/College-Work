/*
 * Enum for debuffs
 * 
 * TODO:
 *      - Probably make more. Other things to do right now
 */

public enum Debuffs {
    Dull,           // Reduces the next instance of damage by X. Removes itself afterwards
    Disadvantage    // Next action you perform has its delay increased by 1. Removes itself after use.
}
