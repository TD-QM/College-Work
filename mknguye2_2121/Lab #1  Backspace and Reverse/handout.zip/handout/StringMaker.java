// A simple class to test JUnit.

public class StringMaker {


//there is a comment:	
	public String concatenate(String one, String two) {
        return one + two;
    }
}
