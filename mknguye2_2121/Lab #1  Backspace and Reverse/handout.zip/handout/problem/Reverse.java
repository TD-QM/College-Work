/**
* Sort a string by their length. If the string has equal length, sort them by alphabetical order.
* Example: Input: a aaaa aa aaa
* 	   Output: aaaa aaa aa a
*/
public class Reverse {
    public static String reverseSort(String str) {
       
    }
}
