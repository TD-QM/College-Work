/**
* Given a string S containing letters and ‘#‘. The ‘#” represents a backspace. The task is to print the new string without ‘#‘.
* Input : S = "abc#de#f#ghi#jklmn#op#"
* Output : abdghjklmo

* Input:  s = "ab##"
* output: ""
*/


public class Backspace {
    public static String erase(String str) {
        
    }
}
