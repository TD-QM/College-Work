public enum Suit {
	SPADES,
	CLUBS,
	DIAMONDS,
	HEARTS;
}
